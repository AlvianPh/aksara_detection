"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class History extends Model {
    static associate(models) {
      History.belongsTo(models.User, { foreignKey: "id_user" });
    }
  }

  History.init(
    {
      foto: DataTypes.STRING,
      hasil: DataTypes.STRING,
      akurasi: DataTypes.FLOAT,
      id_user: DataTypes.INTEGER
    },
    {
      sequelize,
      modelName: "History",
    }
  );

  return History;
};
