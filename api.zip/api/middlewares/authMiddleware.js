const jwt = require("jsonwebtoken");
const { User } = require("../models");

module.exports = async (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({
            status: false,
            data: null,
            message: "Token kosong"
        });
    }

    const token = authHeader.split(" ")[1];

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        const user = await User.findByPk(decoded.id, {
            attributes: { exclude: ["password"] }
        });

        // ❗ Tambahkan validasi user tidak ditemukan
        if (!user) {
            return res.status(401).json({
                status: false,
                data: null,
                message: "User tidak ditemukan"
            });
        }

        req.user = user;

        next();
    } catch (error) {
        return res.status(401).json({
            status: false,
            data: null,
            message: "Token tidak valid"
        });
    }
};
