exports.makeFotoUrl = (filename) => {
  if (!filename) return null;
  return `${process.env.BASE_URL}/uploads/${filename}`;
};

exports.extractFilename = (url) => {
  if (!url) return null;
  return url.split("/").pop(); // ambil nama file saja
};
