exports.sendResponse = (res, status, data, message, code = 200) => {
    return res.status(code).json({
        status,
        data: data ?? null,
        message
    });
};
