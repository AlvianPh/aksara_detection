const express = require("express");
const router = express.Router();

const upload = require("../middlewares/upload");
const auth = require("../middlewares/authMiddleware");
const authController = require("../controllers/authController");

// REGISTER
router.post("/register", upload.single("foto"), authController.register);

// LOGIN
router.post("/login", authController.login);

// PROFILE
router.get("/profile", auth, authController.profile);

// EDIT PROFILE
router.put("/profile", auth, upload.single("foto"), authController.editProfile);

// UBAH PASSWORD
router.put("/change-password", auth, authController.changePassword);

//Delete User
router.delete("/delete", auth, authController.deleteUser);

module.exports = router;
