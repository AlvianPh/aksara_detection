const express = require("express");
const router = express.Router();
const scanController = require("../controllers/scanController");
const upload = require("../middlewares/upload");
const auth = require("../middlewares/authMiddleware");

router.post("/scan", auth, upload.single("foto"), scanController.scanImage);

module.exports = router;
