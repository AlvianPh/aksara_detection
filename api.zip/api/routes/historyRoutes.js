const express = require("express");
const router = express.Router();
const historyController = require("../controllers/historyController");
const auth = require("../middlewares/authMiddleware");
const upload = require("../middlewares/upload");

// GET ALL
router.get("/history", auth, historyController.getHistory);

// GET BY ID
router.get("/history/:id", auth, historyController.getHistoryById);

// simpan history
router.post(
  "/history",
  auth,
  upload.single("foto"),
  historyController.addHistory
);
router.delete("/history/:id", auth, historyController.deleteHistory);

module.exports = router;
