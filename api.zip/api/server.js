require("dotenv").config();
const express = require("express");
const cors = require("cors");
const sequelize = require("./config/db");
const { User } = require("./models");
const historyRoutes = require("./routes/historyRoutes");
// const scanRoutes = require("./routes/scanRoutes");

const app = express();
app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
    allowedHeaders: ["Content-Type", "Authorization"],
    exposedHeaders: ["Content-Length", "Authorization"],
  })
);
app.use(express.json());
app.use("/uploads", express.static("uploads"));

// Routes
const authRoutes = require("./routes/authRoutes");
app.use("/api", authRoutes);
app.use("/api", historyRoutes);
// app.use("/api", scanRoutes);
// Sync Database
sequelize.sync().then(() => {
    console.log("Database synced");
});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});
