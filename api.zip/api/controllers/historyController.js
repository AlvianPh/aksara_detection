const { History } = require("../models");
const { sendResponse } = require("../helpers/response");
const fs = require("fs");
const path = require("path");
const { makeFotoUrl, extractFilename } = require("../helpers/file");

exports.getHistory = async (req, res) => {
  try {
    const idUser = req.user.id;

    // Ambil semua history user
    const histories = await History.findAll({
      where: { id_user: idUser },
      order: [["createdAt", "DESC"]],
    });

    // 📌 Jika tidak punya history → data:null
    if (histories.length === 0) {
      return sendResponse(res, true, null, "History kosong.");
    }

    // Jika punya history → format data
    const result = histories.map((h) => ({
      id: h.id,
      foto: h.foto,
      hasil: h.hasil,
      akurasi: h.akurasi,
      createdAt: h.createdAt,
    }));

    return sendResponse(res, true, result, "History berhasil diambil.");
  } catch (error) {
    return sendResponse(res, false, null, error.message, 500);
  }
};

exports.getHistoryById = async (req, res) => {
  try {
    const { id } = req.params;

    const history = await History.findByPk(id);

    if (!history) {
      return sendResponse(
        res,
        false,
        null,
        { id: "History tidak ditemukan" },
        404
      );
    }

    // ❗ Cek apakah history ini milik user yg login
    if (history.id_user !== req.user.id) {
      return sendResponse(
        res,
        false,
        null,
        "Tidak diizinkan mengakses data user lain.",
        403
      );
    }

    const result = {
      id: history.id,
      foto: history.foto,
      hasil: history.hasil,
      akurasi: history.akurasi,
      createdAt: history.createdAt,
    };

    return sendResponse(res, true, result, "Detail history berhasil diambil.");
  } catch (error) {
    return sendResponse(res, false, null, error.message, 500);
  }
};

exports.addHistory = async (req, res) => {
  try {
    const { hasil, akurasi } = req.body;

    let errors = {};

    if (!hasil) errors.hasil = "Hasil tidak boleh kosong";
    if (!akurasi) errors.akurasi = "Akurasi tidak boleh kosong";

    if (!req.file) errors.foto = "Foto tidak boleh kosong";

    // Jika ada error kirim semuanya
    if (Object.keys(errors).length > 0) {
      return res.status(400).json({
        status: false,
        data: null,
        message: errors,
      });
    }

    const fotoUrl = req.file.filename;

    const history = await History.create({
      foto: fotoUrl,
      hasil,
      akurasi,
      id_user: req.user.id,
    });

    return res.status(201).json({
      status: true,
      data: history,
      message: "History berhasil disimpan.",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      status: false,
      data: null,
      message: error.message,
    });
  }
};

exports.deleteHistory = async (req, res) => {
  try {
    const { id } = req.params;

    // Cari data history
    const history = await History.findByPk(id);

    if (!history) {
      return res.status(404).json({
        status: false,
        data: null,
        message: "History tidak ditemukan.",
      });
    }

    // Cek apakah history ini punya user yang sedang login
    if (history.id_user !== req.user.id) {
      return res.status(403).json({
        status: false,
        data: null,
        message: "Anda tidak memiliki izin untuk menghapus history ini.",
      });
    }

    // Hapus file foto jika ada
    if (history.foto) {
      const filename = extractFilename(history.foto);
      const filePath = path.join(__dirname, "..", "uploads", filename);

      fs.unlink(filePath, (err) => {
        if (err) console.log("Gagal menghapus file:", err.message);
      });
    }

    // Hapus dari database
    await History.destroy({ where: { id } });

    return res.json({
      status: true,
      data: null,
      message: "History berhasil dihapus.",
    });
  } catch (error) {
    return res.status(500).json({
      status: false,
      data: null,
      message: error.message,
    });
  }
};
