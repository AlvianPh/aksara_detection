const fs = require("fs");
const path = require("path");
const sharp = require("sharp");
const tflite = require("tflite-node");
const { History } = require("../models");
const { makeFotoUrl } = require("../helpers/file");

// Load once only
let model = null;
let labels = null;

const loadModel = () => {
  if (!model) {
    const modelPath = "../model/model.tflite";
    model = tflite.loadModel(modelPath);
    console.log("TFLite INT8 model loaded!");
  }

  if (!labels) {
    const labelPath = path.join(__dirname, "..", "model", "label_map.json");
    labels = JSON.parse(fs.readFileSync(labelPath, "utf8"));
    console.log("Label map loaded!");
  }
};

exports.scanImage = async (req, res) => {
  try {
    loadModel();

    if (!req.foto) {
      return res.status(400).json({
        status: false,
        data: null,
        message: "Gambar tidak ditemukan",
      });
    }

    const imagePath = path.join(__dirname, "..", "uploads", req.foto.filename);

    // Resize input image to 224x224, get raw RGB (uint8)
    const inputBuffer = await sharp(imagePath)
      .resize(224, 224)
      .removeAlpha()
      .raw()
      .toBuffer();

    // Tensor: uint8 with shape [1, 224, 224, 3]
    const tensor = {
      data: new Uint8Array(inputBuffer),
      shape: [1, 224, 224, 3],
      type: "uint8",
    };

    // Predict
    const output = model.predict(tensor);
    const probabilities = output.data; // Uint8Array (0–255)

    // Convert ke akurasi %
    const maxValue = Math.max(...probabilities);
    const maxIndex = probabilities.indexOf(maxValue);

    const hasil = labels[maxIndex.toString()];
    const akurasi = (maxValue / 255) * 100;

    // Foto URL
    const fotoUrl = makeFotoUrl(req.foto.filename);

    // Simpan history
    await History.create({
      foto: fotoUrl,
      hasil,
      akurasi,
      id_user: req.user.id,
    });

    return res.json({
      status: true,
      data: {
        foto: fotoUrl,
        hasil,
        akurasi,
      },
      message: "Scan berhasil",
    });
  } catch (error) {
    console.error("SCAN ERROR:", error);
    return res.status(500).json({
      status: false,
      data: null,
      message: error.message,
    });
  }
};
