const fs = require("fs");
const path = require("path");
const { User } = require("../models");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { sendResponse } = require("../helpers/response"); // jika menggunakan helper ini
const { makeFotoUrl, extractFilename } = require("../helpers/file");

exports.register = async (req, res) => {
  try {
    const { name, username, password, confirmPassword } = req.body;
    let errors = {};

    const fotoFilename = req.file ? req.file.filename : null;
    const fotoUrl = makeFotoUrl(fotoFilename);

    // Validasi NAME
    if (!name || name.trim() === "") {
      errors.name = "Nama tidak boleh kosong";
    } else if (!/^[A-Za-z\s]+$/.test(name)) {
      errors.name = "Nama tidak boleh mengandung angka atau simbol.";
    }

    // Validasi USERNAME
    if (!username || username.trim() === "") {
      errors.username = "Username tidak boleh kosong";
    } else {
      const exist = await User.findOne({ where: { username } });
      if (exist) errors.username = "Username sudah digunakan.";
    }

    if (!password) errors.password = "Password tidak boleh kosong";
    if (!confirmPassword)
      errors.confirmPassword = "Konfirmasi password tidak boleh kosong";
    else if (password !== confirmPassword)
      errors.confirmPassword = "Konfirmasi password tidak sama";

    if (Object.keys(errors).length > 0) {
      return sendResponse(res, false, null, errors, 400);
    }

    const hash = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      username,
      password: hash,
      foto: fotoUrl,
    });

    const responseUser = {
      id: user.id,
      name: user.name,
      username: user.username,
      foto: user.foto,
    };

    return sendResponse(res, true, responseUser, "Registrasi berhasil.");
  } catch (error) {
    return sendResponse(res, false, null, error.message, 500);
  }
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    let errors = {};

    if (!username) errors.username = "Username tidak boleh kosong";
    if (!password) errors.password = "Password tidak boleh kosong";

    if (Object.keys(errors).length > 0) {
      return sendResponse(res, false, null, errors, 400);
    }

    const user = await User.findOne({ where: { username } });
    if (!user)
      return sendResponse(
        res,
        false,
        null,
        { username: "User tidak ditemukan" },
        400
      );

    const match = await bcrypt.compare(password, user.password);
    if (!match)
      return sendResponse(
        res,
        false,
        null,
        { password: "Password salah" },
        400
      );

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    return sendResponse(res, true, { token }, "Login berhasil.");
  } catch (error) {
    return sendResponse(res, false, null, error.message, 500);
  }
};

exports.profile = async (req, res) => {
  try {
    const user = req.user;

    if (!user) {
      return sendResponse(res, false, null, "User tidak ditemukan", 404);
    }

    const foto = user.foto ? user.foto : null;

    return sendResponse(
      res,
      true,
      { ...user.dataValues, foto },
      "Data profil berhasil diambil."
    );
  } catch (error) {
    return sendResponse(res, false, null, error.message, 500);
  }
};

exports.editProfile = async (req, res) => {
  try {
    const { name, username } = req.body;
    const user = await User.findByPk(req.user.id);

    if (!user) {
      return sendResponse(
        res,
        false,
        null,
        { user: "User tidak ditemukan" },
        404
      );
    }

    let errors = {};

    if (name === undefined || name.trim() === "") {
      errors.name = "Nama tidak boleh kosong";
    }

    if (username === undefined || username.trim() === "") {
      errors.username = "Username tidak boleh kosong";
    }

    if (Object.keys(errors).length > 0) {
      return sendResponse(res, false, null, errors, 400);
    }

    const updateData = {};

    if (name !== undefined) updateData.name = name;
    if (username !== undefined) updateData.username = username;

    // Jika upload foto baru
    if (req.file) {
      const oldFilename = extractFilename(user.foto);
      if (oldFilename) {
        const oldPath = path.join(__dirname, "..", "uploads", oldFilename);
        fs.unlink(
          oldPath,
          (err) => err && console.log("Gagal hapus file lama:", err.message)
        );
      }

      updateData.foto = makeFotoUrl(req.file.filename);
    }

    await User.update(updateData, { where: { id: req.user.id } });

    const updated = await User.findByPk(req.user.id, {
      attributes: { exclude: ["password"] },
    });

    return sendResponse(res, true, updated, "Profil berhasil diperbarui.");
  } catch (error) {
    return sendResponse(res, false, null, error.message, 500);
  }
};

exports.changePassword = async (req, res) => {
  try {
    const { oldPassword, newPassword, confirmPassword } = req.body;

    let errors = {};

    if (!oldPassword) errors.oldPassword = "Password lama tidak boleh kosong";
    if (!newPassword) errors.newPassword = "Password baru tidak boleh kosong";
    if (!confirmPassword)
      errors.confirmPassword = "Konfirmasi password tidak boleh kosong";
    if (newPassword && confirmPassword && newPassword !== confirmPassword) {
      errors.confirmPassword = "Konfirmasi password tidak cocok";
    }

    if (Object.keys(errors).length > 0) {
      return res.status(400).json({
        status: false,
        data: null,
        message: errors,
      });
    }

    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({
        status: false,
        data: null,
        message: { user: "User tidak ditemukan" },
      });
    }

    const match = await bcrypt.compare(oldPassword, user.password);
    if (!match) {
      return res.status(400).json({
        status: false,
        data: null,
        message: { oldPassword: "Password lama salah" },
      });
    }

    const hash = await bcrypt.hash(newPassword, 10);

    await User.update({ password: hash }, { where: { id: req.user.id } });

    return res.status(200).json({
      status: true,
      data: null,
      message: "Password berhasil diganti.",
    });
  } catch (error) {
    return res.status(500).json({
      status: false,
      data: null,
      message: error.message,
    });
  }
};

// DELETE USER
exports.deleteUser = async (req, res) => {
  try {
    const userId = req.user.id; // Mengambil ID user dari token JWT

    // Cari user berdasarkan ID
    const user = await User.findByPk(userId);
    if (!user) {
      return sendResponse(res, false, null, "User tidak ditemukan", 404);
    }

    // Menghapus foto user jika ada
    if (user.foto) {
      const oldFilename = extractFilename(user.foto);
      const oldPath = path.join(__dirname, "..", "uploads", oldFilename);
      fs.unlink(oldPath, (err) => {
        if (err) console.log("Gagal hapus foto:", err.message);
      });
    }

    // Hapus user dari database
    await User.destroy({ where: { id: userId } });

    // Mengembalikan respon sukses
    return sendResponse(res, true, null, "User berhasil dihapus.");
  } catch (error) {
    return sendResponse(res, false, null, error.message, 500);
  }
};
